# backend/models.py

from pydantic import BaseModel, Field
from typing import Optional
from datetime import date


# ── Deviation schemas ─────────────────────────────────────────────────────────

class DeviationCreate(BaseModel):
    """Shape of the request body when creating a new deviation."""
    type: str = Field(..., example="billing credit")
    # type must be one of these — validated in the router
    customer_name: str = Field(..., example="GlobalTel Media Inc.")
    account_id: Optional[str] = Field(None, example="ACC-10042")
    scope: Optional[str] = Field(None, example="Overcharge on bandwidth burst usage")
    requested_value: Optional[float] = Field(None, example=12450.00)
    standard_limit: Optional[float] = Field(None, example=15000.00)
    urgency: Optional[str] = Field("Medium", example="High")
    expiry_date: Optional[str] = Field(None, example="2025-06-30")
    raised_by: str = Field(..., example="ops_user")


class DeviationResponse(BaseModel):
    """Shape of a deviation returned by the API."""
    id: str
    type: str
    customer_name: str
    account_id: Optional[str]
    scope: Optional[str]
    requested_value: Optional[float]
    standard_limit: Optional[float]
    urgency: str
    expiry_date: Optional[str]
    status: str
    raised_by: str
    ai_justification: Optional[str]
    policy_refs: Optional[str]
    created_at: str
    updated_at: str


# ── Approval schemas ──────────────────────────────────────────────────────────

class ApprovalStepResponse(BaseModel):
    """One step in the sequential approval queue."""
    id: int
    deviation_id: str
    step_order: int
    role_required: str
    label: str
    status: str                  # waiting, pending, approved, rejected
    acted_by: Optional[str]
    comment: Optional[str]
    ai_suggestion: Optional[str]
    timestamp: Optional[str]


class ApprovalAction(BaseModel):
    """Request body when a user approves or rejects a step."""
    action: str = Field(..., example="approve")   # "approve" or "reject"
    actor: str  = Field(..., example="finance_user")
    comment: Optional[str] = Field(None, example="Credit within Tier-2 limit. Approved.")


# ── Audit schema ──────────────────────────────────────────────────────────────

class AuditEntry(BaseModel):
    """One entry in the immutable audit log."""
    id: int
    deviation_id: Optional[str]
    action: str
    actor: str
    timestamp: str