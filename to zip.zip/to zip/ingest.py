# backend/rag/ingest.py

# ── SSL patch — must be FIRST, before any other import ───────────────────────
# Tiktoken calls requests.get() at import time to download its BPE file.
# On corporate networks the proxy blocks this with an SSL error.
# This patch disables SSL verification inside requests globally for this process.
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_original_get = requests.get
def _patched_get(url, **kwargs):
    kwargs["verify"] = False
    return _original_get(url, **kwargs)
requests.get = _patched_get
# ── End SSL patch ─────────────────────────────────────────────────────────────

import os
import sys
import httpx
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma

DATA_DIR   = os.path.join(os.path.dirname(__file__), "data")
CHROMA_DIR = os.path.join(os.path.dirname(__file__), "chroma_store")


def get_embedding_model():
    return OpenAIEmbeddings(
        model="azure/genailab-maas-text-embedding-3-large",  # ← full name for LiteLLM routing
        openai_api_key=os.getenv("GENAI_API_KEY"),
        openai_api_base="https://genailab.tcs.in",
        openai_api_type="openai",
        chunk_size=100,
        tiktoken_model_name="cl100k_base",   # ← use base encoding name, already cached locally
        http_client=httpx.Client(verify=False),
        http_async_client=httpx.AsyncClient(verify=False)
    )


def ingest_policies():
    print("📂 Loading policy documents...")

    documents = []
    for filename in os.listdir(DATA_DIR):
        if filename.endswith(".txt"):
            filepath = os.path.join(DATA_DIR, filename)
            loader = TextLoader(filepath, encoding="utf-8")
            docs = loader.load()
            for doc in docs:
                doc.metadata["source"] = filename
            documents.extend(docs)
            print(f"  ✅ Loaded: {filename} ({len(docs[0].page_content)} chars)")

    if not documents:
        print("❌ No .txt files found in data/. Check the path.")
        sys.exit(1)

    print(f"\n✂️  Splitting {len(documents)} documents into chunks...")

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=80,
        length_function=len,
        separators=["\n\n", "\n", " ", ""]
    )
    chunks = splitter.split_documents(documents)
    print(f"  ✅ Created {len(chunks)} chunks")

    print("\n🔢 Embedding chunks and storing in ChromaDB...")
    print("   (This calls the Azure embedding API — may take 30–60 seconds)")

    embedding_model = get_embedding_model()

    vectorstore = Chroma.from_documents(
        documents=chunks,
        embedding=embedding_model,
        persist_directory=CHROMA_DIR,
        collection_name="telcoflow_policies"
    )

    print(f"\n✅ Vector store built: {len(chunks)} chunks stored in {CHROMA_DIR}")
    return vectorstore


if __name__ == "__main__":
    ingest_policies()