# backend/agents/approval_graph.py

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from langgraph.graph import StateGraph, END
from langgraph.types import interrupt, Command    # SqliteSaver removed from here

from agents.advisor import ApprovalWorkflowState, advisor_node
from database import get_connection, write_audit

CHECKPOINT_DB = os.path.join(os.path.dirname(__file__), "..", "workflow_checkpoints.db")

APPROVAL_CHAIN = [
    (0, "ops",        "Operations"),
    (1, "finance",    "Finance"),
    (2, "network",    "Network"),
    (3, "compliance", "Compliance"),
]


# ── Node: load_deviation ──────────────────────────────────────────────────────

def load_deviation_node(state: ApprovalWorkflowState) -> ApprovalWorkflowState:
    """
    Loads the full deviation record and the current pending approval step
    from the database into the graph state.
    Called once at the start of the workflow.
    """
    print(f"\n📋 [Load Node] Loading deviation {state['deviation_id']}...")

    conn = get_connection()

    # Fetch deviation
    dev = conn.execute(
        "SELECT * FROM deviations WHERE id = ?",
        (state["deviation_id"],)
    ).fetchone()

    if not dev:
        conn.close()
        raise ValueError(f"Deviation {state['deviation_id']} not found")

    # Fetch the first pending step
    step = conn.execute(
        """SELECT * FROM approval_steps
           WHERE deviation_id = ? AND status = 'pending'
           ORDER BY step_order ASC LIMIT 1""",
        (state["deviation_id"],)
    ).fetchone()

    conn.close()

    if not step:
        print("  ⚠️  No pending steps found — workflow may already be complete")
        return {
            **state,
            "workflow_status": "approved",
            "current_step_index": 4,
        }

    step_index = step["step_order"] - 1   # DB is 1-indexed, our list is 0-indexed

    print(f"  ✅ Loaded — current step: {step['label']} (step {step['step_order']} of 4)")

    return {
        **state,
        "deviation_type":   dev["type"],
        "customer_name":    dev["customer_name"],
        "requested_value":  float(dev["requested_value"] or 0),
        "standard_limit":   float(dev["standard_limit"] or 0),
        "scope":            dev["scope"] or "",
        "urgency":          dev["urgency"] or "Medium",
        "risk_level":       "",           # filled by analysis graph earlier
        "ai_justification": dev["ai_justification"] or "",
        "policy_refs":      dev["policy_refs"] or "",
        "current_step_index": step_index,
        "current_step_id":    step["id"],
        "current_role":       step["role_required"],
        "current_label":      step["label"],
        "workflow_status":    "running",
        "decisions":          state.get("decisions", []),
    }


# ── Node: human_approval (interrupt point) ────────────────────────────────────

def human_approval_node(state: ApprovalWorkflowState) -> ApprovalWorkflowState:
    """
    This node PAUSES the graph and waits for a human decision.

    interrupt() saves the current state to the checkpointer DB and
    raises an internal signal that suspends execution.
    When the human acts via the API, we call graph.invoke() again
    with the human's decision, and execution resumes here.
    """
    print(f"\n⏸  [Human Approval Node] Waiting for {state['current_label']} decision...")
    print(f"    Step ID: {state['current_step_id']} | Role: {state['current_role']}")

    # interrupt() pauses execution here and returns the value passed
    # to the next graph.invoke() call as state["human_action"] etc.
    # The dict we pass to interrupt() is what gets sent back to the caller
    # so they know what's waiting.
    human_input = interrupt({
        "waiting_for":  state["current_label"],
        "role":         state["current_role"],
        "step_id":      state["current_step_id"],
        "ai_suggestion": state["ai_suggestion"],
        "deviation_id": state["deviation_id"],
    })

    # When resumed, human_input contains the dict passed by the API caller
    # e.g. {"action": "approve", "actor": "finance_user", "comment": "..."}
    return {
        **state,
        "human_action":  human_input.get("action"),
        "human_actor":   human_input.get("actor"),
        "human_comment": human_input.get("comment", ""),
    }


# ── Node: process_decision ────────────────────────────────────────────────────

def process_decision_node(state: ApprovalWorkflowState) -> ApprovalWorkflowState:
    """
    Records the human decision to the database and updates workflow state.
    Advances the queue to the next step on approval,
    or closes the deviation on rejection.
    """
    action  = state["human_action"]
    actor   = state["human_actor"]
    comment = state["human_comment"] or ""
    step_id = state["current_step_id"]
    dev_id  = state["deviation_id"]

    print(f"\n📝 [Decision Node] Processing: {action} by {actor} on step {step_id}")

    conn = get_connection()

    try:
        if action == "approve":
            # Mark current step approved
            conn.execute(
                """UPDATE approval_steps
                   SET status='approved', acted_by=?, comment=?, timestamp=datetime('now')
                   WHERE id=?""",
                (actor, comment or "Approved", step_id)
            )
            write_audit(
                conn, dev_id,
                f"{state['current_label']} approval granted. Comment: {comment or 'None'}",
                actor
            )

            # Find next waiting step
            next_step = conn.execute(
                """SELECT * FROM approval_steps
                   WHERE deviation_id=? AND status='waiting'
                   ORDER BY step_order ASC LIMIT 1""",
                (dev_id,)
            ).fetchone()

            if next_step:
                # Activate next step
                conn.execute(
                    "UPDATE approval_steps SET status='pending' WHERE id=?",
                    (next_step["id"],)
                )
                write_audit(
                    conn, dev_id,
                    f"{next_step['label']} step activated for review",
                    "system"
                )
                next_index = next_step["step_order"] - 1

                conn.commit()
                conn.close()

                # Record decision and advance to next step
                decisions = state.get("decisions", [])
                decisions.append({
                    "step":    state["current_label"],
                    "role":    state["current_role"],
                    "action":  "approved",
                    "actor":   actor,
                    "comment": comment
                })

                return {
                    **state,
                    "current_step_index": next_index,
                    "current_step_id":    next_step["id"],
                    "current_role":       next_step["role_required"],
                    "current_label":      next_step["label"],
                    "workflow_status":    "running",
                    "human_action":       None,
                    "human_actor":        None,
                    "human_comment":      None,
                    "decisions":          decisions,
                }

            else:
                # All steps approved — finalise
                conn.execute(
                    """UPDATE deviations
                       SET status='approved', updated_at=datetime('now')
                       WHERE id=?""",
                    (dev_id,)
                )
                write_audit(
                    conn, dev_id,
                    "DEVIATION FULLY APPROVED — Ready for execution",
                    "workflow"
                )
                conn.commit()
                conn.close()

                decisions = state.get("decisions", [])
                decisions.append({
                    "step":    state["current_label"],
                    "role":    state["current_role"],
                    "action":  "approved",
                    "actor":   actor,
                    "comment": comment
                })

                return {
                    **state,
                    "workflow_status": "approved",
                    "decisions":       decisions,
                }

        else:  # reject
            conn.execute(
                """UPDATE approval_steps
                   SET status='rejected', acted_by=?, comment=?, timestamp=datetime('now')
                   WHERE id=?""",
                (actor, comment, step_id)
            )
            conn.execute(
                """UPDATE deviations
                   SET status='rejected', updated_at=datetime('now')
                   WHERE id=?""",
                (dev_id,)
            )
            write_audit(
                conn, dev_id,
                f"DEVIATION REJECTED by {state['current_label']}: {comment}",
                actor
            )
            conn.commit()
            conn.close()

            decisions = state.get("decisions", [])
            decisions.append({
                "step":    state["current_label"],
                "role":    state["current_role"],
                "action":  "rejected",
                "actor":   actor,
                "comment": comment
            })

            return {
                **state,
                "workflow_status":  "rejected",
                "rejection_reason": comment,
                "decisions":        decisions,
            }

    except Exception as e:
        conn.rollback()
        conn.close()
        raise e


# ── Node: finalise ────────────────────────────────────────────────────────────

# backend/agents/approval_graph.py
# Replace the existing finalise_node function

def finalise_node(state: ApprovalWorkflowState) -> ApprovalWorkflowState:
    """
    Final node — runs when workflow is complete.
    Automatically triggers the Audit Summariser Agent.
    """
    print(f"\n🏁 [Finalise Node] Workflow complete — status: {state['workflow_status']}")

    conn = get_connection()
    write_audit(
        conn,
        state["deviation_id"],
        f"Workflow finalised. Outcome: {state['workflow_status']}. "
        f"Total decisions: {len(state.get('decisions', []))}",
        "workflow"
    )
    conn.commit()
    conn.close()

    # Auto-trigger the Audit Summariser Agent
    try:
        from agents.auditor import generate_audit_summary
        generate_audit_summary(state["deviation_id"])
        print("  ✅ Audit summary auto-generated")
    except Exception as e:
        # Non-fatal — summary can be triggered manually via API
        print(f"  ⚠️  Auto-summary failed (non-fatal): {e}")

    return state


# ── Routing functions ─────────────────────────────────────────────────────────

def route_after_decision(state: ApprovalWorkflowState) -> str:
    """
    After process_decision_node, decide what comes next:
    - rejected  → end immediately
    - approved  → all done → finalise
    - running   → more steps remain → go back to advisor for next step
    """
    status = state.get("workflow_status")
    if status == "rejected":
        return "end"
    if status == "approved":
        return "finalise"
    return "advisor"     # still running — more steps to go


# ── Build the graph ───────────────────────────────────────────────────────────

def build_approval_graph():
    """
    Builds and compiles the approval workflow graph with SQLite checkpointer.
    Uses a direct sqlite3 connection instead of from_conn_string()
    to avoid the context manager issue in newer langgraph versions.
    """
    import sqlite3
    from langgraph.checkpoint.sqlite import SqliteSaver

    # Open a persistent SQLite connection for the checkpointer
    # check_same_thread=False is required — FastAPI uses multiple threads
    conn = sqlite3.connect(CHECKPOINT_DB, check_same_thread=False)

    # Pass the connection directly — this gives a proper BaseCheckpointSaver instance
    checkpointer = SqliteSaver(conn)

    graph = StateGraph(ApprovalWorkflowState)

    graph.add_node("load_deviation",   load_deviation_node)
    graph.add_node("advisor",          advisor_node)
    graph.add_node("human_approval",   human_approval_node)
    graph.add_node("process_decision", process_decision_node)
    graph.add_node("finalise",         finalise_node)

    graph.set_entry_point("load_deviation")

    graph.add_edge("load_deviation",  "advisor")
    graph.add_edge("advisor",         "human_approval")
    graph.add_edge("human_approval",  "process_decision")

    graph.add_conditional_edges(
        "process_decision",
        route_after_decision,
        {
            "advisor":  "advisor",
            "finalise": "finalise",
            "end":      END
        }
    )

    graph.add_edge("finalise", END)

    return graph.compile(
        checkpointer=checkpointer,
        interrupt_before=["human_approval"]
    )


# Build once at import time
approval_graph = build_approval_graph()


# ── Public API functions ──────────────────────────────────────────────────────

def start_approval_workflow(deviation_id: str, thread_id: str) -> dict:
    """
    Starts the approval workflow for a deviation.
    Each deviation gets a unique thread_id so checkpoints don't mix.

    The graph will run until it hits the first interrupt (human_approval node)
    then pause and return the interrupt payload.

    Args:
        deviation_id: e.g. "DEV-2410-A3F2"
        thread_id:    unique ID for this workflow run, use deviation_id

    Returns:
        dict with current step info and AI suggestion
    """
    config = {"configurable": {"thread_id": thread_id}}

    initial_state: ApprovalWorkflowState = {
        "deviation_id":       deviation_id,
        "deviation_type":     "",
        "customer_name":      "",
        "requested_value":    0.0,
        "standard_limit":     0.0,
        "scope":              "",
        "urgency":            "",
        "risk_level":         "",
        "ai_justification":   "",
        "policy_refs":        "",
        "current_step_index": 0,
        "current_step_id":    0,
        "current_role":       "",
        "current_label":      "",
        "human_action":       None,
        "human_actor":        None,
        "human_comment":      None,
        "ai_suggestion":      "",
        "workflow_status":    "running",
        "rejection_reason":   None,
        "decisions":          [],
    }

    print(f"\n🚀 Starting approval workflow for {deviation_id} (thread: {thread_id})")

    # Run until first interrupt
    result = approval_graph.invoke(initial_state, config)

    return _extract_interrupt_info(result, thread_id)

ROLE_PERMISSIONS = {
    "ops":        ["ops",        "senior"],
    "finance":    ["finance",    "senior"],
    "network":    ["network",    "senior"],
    "compliance": ["compliance", "senior"],
}

def _infer_role_from_actor(actor: str) -> str:
    """
    Derives the role from the actor username convention.
    e.g. 'finance_user' → 'finance', 'senior_user' → 'senior'
    """
    for role in ("ops", "finance", "network", "compliance", "senior", "admin"):
        if role in actor.lower():
            return role
    return "unknown"


def _check_role_permission(thread_id: str, actor: str) -> tuple[bool, str, str]:
    """
    Checks whether the actor has permission to act on the current
    pending step of the workflow.

    Returns:
        (allowed: bool, actor_role: str, required_role: str)
    """
    config = {"configurable": {"thread_id": thread_id}}
    state  = approval_graph.get_state(config)

    if not state or not state.values:
        return False, "unknown", "unknown"

    current_role_required = state.values.get("current_role", "")
    actor_role            = _infer_role_from_actor(actor)
    allowed_roles         = ROLE_PERMISSIONS.get(current_role_required, [])
    allowed               = actor_role in allowed_roles

    return allowed, actor_role, current_role_required

def resume_approval_workflow(thread_id: str, action: str,
                              actor: str, comment: str = "") -> dict:
    """
    Resumes a paused workflow after a human decision.
    Enforces role-based access — raises PermissionError if the actor
    does not have the required role for the current pending step.

    Args:
        thread_id: must match the thread_id used in start_approval_workflow
        action:    "approve" or "reject"
        actor:     username of the person acting
        comment:   optional comment (mandatory for rejection)

    Raises:
        PermissionError: if the actor's role does not match the required step role
        ValueError:      if no active workflow found for this thread_id

    Returns:
        dict with next step info, or final status if workflow is complete
    """
    config = {"configurable": {"thread_id": thread_id}}

    # ── Role enforcement check BEFORE resuming the graph ─────────────────────
    allowed, actor_role, required_role = _check_role_permission(thread_id, actor)

    if not allowed:
        raise PermissionError(
            f"Access denied. Step requires role '{required_role}' or 'senior'. "
            f"Actor '{actor}' has role '{actor_role}'."
        )

    print(f"\n▶️  Resuming workflow thread {thread_id} — action: {action} by {actor} "
          f"(role: {actor_role})")

    result = approval_graph.invoke(
        Command(resume={"action": action, "actor": actor, "comment": comment}),
        config
    )

    return _extract_interrupt_info(result, thread_id)


def _extract_interrupt_info(result: dict, thread_id: str) -> dict:
    """
    Extracts the relevant info from the graph result to return to the API caller.
    Handles both interrupted (still running) and completed states.
    """
    status = result.get("workflow_status", "running")

    if status in ("approved", "rejected"):
        return {
            "thread_id":        thread_id,
            "workflow_status":  status,
            "deviation_id":     result.get("deviation_id"),
            "rejection_reason": result.get("rejection_reason"),
            "decisions":        result.get("decisions", []),
            "waiting_for":      None,
        }

    # Still running — interrupted at next human step
    return {
        "thread_id":        thread_id,
        "workflow_status":  "waiting_for_approval",
        "deviation_id":     result.get("deviation_id"),
        "waiting_for":      result.get("current_label"),
        "current_role":     result.get("current_role"),
        "current_step_id":  result.get("current_step_id"),
        "ai_suggestion":    result.get("ai_suggestion"),
        "decisions_so_far": result.get("decisions", []),
    }