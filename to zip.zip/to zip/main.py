# backend/main.py

import os
import sys
import logging
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from database import init_db, seed_users
from routers.deviations import router as deviations_router
from routers.approvals  import router as approvals_router
from routers.audit      import router as audit_router

# ── Logging setup ─────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("telcoflow.log", encoding="utf-8")
    ]
)
logger = logging.getLogger("telcoflow")

# ── App ────────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="TelcoFlow AI API",
    description="AI-Assisted Service Deviation & Approval Workflow",
    version="1.0.0"
)

# ── CORS ───────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://localhost:3000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Global exception handlers ──────────────────────────────────────────────────

@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    """
    Catches all HTTPExceptions raised anywhere in the app.
    Returns clean JSON instead of HTML error pages.
    """
    logger.warning(f"HTTP {exc.status_code} on {request.url}: {exc.detail}")
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error":   True,
            "status":  exc.status_code,
            "detail":  exc.detail,
            "path":    str(request.url)
        }
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """
    Catches Pydantic validation errors (wrong field types, missing required fields).
    Returns a readable list of what went wrong instead of a cryptic 422.
    """
    errors = []
    for err in exc.errors():
        field = " → ".join(str(e) for e in err["loc"])
        errors.append({ "field": field, "message": err["msg"] })

    logger.warning(f"Validation error on {request.url}: {errors}")
    return JSONResponse(
        status_code=422,
        content={
            "error":   True,
            "status":  422,
            "detail":  "Request validation failed",
            "errors":  errors
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """
    Catches any unhandled Python exception.
    Logs the full traceback but returns a safe generic message to the client.
    """
    logger.exception(f"Unhandled exception on {request.url}: {exc}")
    return JSONResponse(
        status_code=500,
        content={
            "error":  True,
            "status": 500,
            "detail": "An internal server error occurred. Check telcoflow.log for details."
        }
    )

# ── Routers ────────────────────────────────────────────────────────────────────
app.include_router(deviations_router)
app.include_router(approvals_router)
app.include_router(audit_router)

# ── Startup ────────────────────────────────────────────────────────────────────
@app.on_event("startup")
def on_startup():
    init_db()
    seed_users()
    logger.info("TelcoFlow AI API started successfully")


# ── Health check (expanded) ───────────────────────────────────────────────────
@app.get("/health", tags=["System"])
def health_check():
    """
    Checks DB connectivity and RAG vector store availability.
    Returns status of each subsystem so you can diagnose partial failures.
    """
    from database import get_connection
    import os

    status = { "api": "ok", "database": "unknown", "rag": "unknown" }

    # Check DB
    try:
        conn = get_connection()
        conn.execute("SELECT COUNT(*) FROM deviations").fetchone()
        conn.close()
        status["database"] = "ok"
    except Exception as e:
        status["database"] = f"error: {str(e)}"

    # Check RAG vector store exists on disk
    chroma_path = os.path.join(
        os.path.dirname(__file__), "rag", "chroma_store"
    )
    status["rag"] = "ok" if os.path.exists(chroma_path) else \
                    "not initialised — run rag/ingest.py"

    overall = "ok" if all(v == "ok" for v in status.values()) else "degraded"
    return { "status": overall, "subsystems": status }