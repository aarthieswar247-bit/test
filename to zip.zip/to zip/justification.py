# backend/agents/justification.py

import os
import sys
import httpx
import urllib3

# SSL patch — same as ingest.py, needed before any import that triggers tiktoken
import requests as _requests
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
_orig_get = _requests.get
def _patched_get(url, **kwargs):
    kwargs["verify"] = False
    return _orig_get(url, **kwargs)
_requests.get = _patched_get

from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

# Import retriever — loads ChromaDB on first import
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from rag.retriever import retrieve_as_context

from agents.guardrail import DeviationState


# ── LLM client ────────────────────────────────────────────────────────────────

def get_llm():
    """
    Returns the GPT-4.1 client pointed at the TCS GenAI gateway.
    SSL verification is disabled for corporate proxy compatibility.
    """
    return ChatOpenAI(
        model="azure/genailab-maas-gpt-4.1",
        api_key=os.getenv("GENAI_API_KEY"),
        base_url="https://genailab.tcs.in",
        http_client=httpx.Client(verify=False),
        http_async_client=httpx.AsyncClient(verify=False),
        temperature=0.2,      # low temperature = consistent, formal output
        max_tokens=800
    )


# ── System prompt ─────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """You are a compliance documentation specialist for a Telecom/Media company.
Your job is to write formal, professional business justifications for operational deviations.

Rules you must follow:
- Always reference specific policy clauses from the context provided
- Use formal business language suitable for regulatory review
- Structure the justification in 3 short paragraphs:
  Paragraph 1: Nature of the deviation and business reason
  Paragraph 2: Policy/regulatory basis that permits this deviation
  Paragraph 3: Risk mitigation and why approval is appropriate
- End with a "Policy References:" line listing the specific clauses cited
- Keep the total response under 300 words
- Never fabricate policy clauses — only cite what is in the provided context"""


def justification_node(state: DeviationState) -> DeviationState:
    """
    Generates a compliance-friendly AI justification using RAG + GPT-4.1.

    Steps:
    1. Build a semantic query from the deviation context
    2. Retrieve relevant policy chunks from ChromaDB
    3. Send system prompt + policy context + deviation details to GPT-4.1
    4. Parse the response into justification text and policy references
    5. Write results back to state

    Sets:
        state["retrieved_context"]  = raw policy chunks retrieved
        state["ai_justification"]   = the generated justification text
        state["policy_refs"]        = extracted policy clause references
    """

    print(f"\n🧠 [Justification Agent] Generating justification for "
          f"'{state['deviation_type']}' — {state['customer_name']}")

    # ── Step 1: Build the RAG query from deviation context ────────────────────
    # We combine multiple fields to give the retriever the richest possible
    # semantic signal — type + scope + customer context
    rag_query = (
        f"{state['deviation_type']} "
        f"{state.get('scope', '')} "
        f"policy clause approval threshold regulatory compliance "
        f"customer {state['customer_name']}"
    )

    # ── Step 2: Retrieve relevant policy chunks ───────────────────────────────
    print("  📚 Retrieving policy context from ChromaDB...")
    policy_context = retrieve_as_context(rag_query, k=5)
    print(f"  ✅ Retrieved context ({len(policy_context)} chars)")

    # ── Step 3: Build the user prompt ─────────────────────────────────────────
    user_prompt = f"""Generate a compliance justification for the following operational deviation:

DEVIATION DETAILS:
- Type: {state['deviation_type']}
- Customer: {state['customer_name']}
- Requested Value: {state.get('requested_value', 'N/A')}
- Standard Limit: {state.get('standard_limit', 'N/A')}
- Scope: {state.get('scope', 'Not specified')}
- Urgency: {state.get('urgency', 'Medium')}
- Risk Level: {state.get('risk_level', 'Medium')}
- Raised By: {state.get('raised_by', 'N/A')}

RELEVANT POLICY CONTEXT (use ONLY these clauses — do not invent others):
{policy_context}

Write the 3-paragraph justification now, ending with the Policy References line."""

    # ── Step 4: Call GPT-4.1 ──────────────────────────────────────────────────
    print("  🤖 Calling GPT-4.1 for justification...")
    try:
        llm = get_llm()
        messages = [
            SystemMessage(content=SYSTEM_PROMPT),
            HumanMessage(content=user_prompt)
        ]
        response = llm.invoke(messages)
        justification_text = response.content.strip()
        print("  ✅ Justification generated successfully")

    except Exception as e:
        print(f"  ❌ LLM call failed: {e}")
        return {
            **state,
            "error": f"Justification generation failed: {str(e)}",
            "ai_justification": "AI justification unavailable — manual review required.",
            "policy_refs": "",
            "retrieved_context": policy_context
        }

    # ── Step 5: Extract policy references from the response ───────────────────
    # The LLM is instructed to end with "Policy References: ..."
    # We split on that line and store the references separately
    policy_refs = ""
    if "Policy References:" in justification_text:
        parts = justification_text.split("Policy References:")
        justification_text = parts[0].strip()
        policy_refs = "Policy References:" + parts[1].strip()

    return {
        **state,
        "retrieved_context":  policy_context,
        "ai_justification":   justification_text,
        "policy_refs":        policy_refs,
        "error":              None
    }