# backend/agents/guardrail.py

from typing import TypedDict, Optional


# ── Shared State definition ───────────────────────────────────────────────────
# This TypedDict is the shared "memory" passed between all agents in the graph.
# Every agent reads from and writes to this same structure.

class DeviationState(TypedDict):
    # Input fields (set before the graph starts)
    deviation_id:      str
    deviation_type:    str          # billing credit, bandwidth, sla waiver, etc.
    customer_name:     str
    requested_value:   float
    standard_limit:    float
    urgency:           str
    scope:             str
    raised_by:         str

    # Guardrail outputs (set by guardrail_node)
    guardrail_passed:  bool
    guardrail_reason:  str          # why it was blocked (empty if passed)
    risk_level:        str          # Low, Medium, High, Critical

    # Justification outputs (set by justification_node)
    ai_justification:  str
    policy_refs:       str          # comma-separated clause references
    retrieved_context: str          # raw RAG output (stored for audit)

    # Error field
    error:             Optional[str]


# ── Threshold table ───────────────────────────────────────────────────────────
# These match the thresholds defined in our synthetic policy documents.
# Guardrail checks requested_value against these before allowing submission.

THRESHOLDS = {
    "billing credit": {
        "tier1_max":  10_000,   # Ops + Finance only
        "tier2_max":  50_000,   # Full chain required
        "hard_limit": 100_000,  # Absolute ceiling — blocked regardless
    },
    "bandwidth": {
        "tier1_max":  20,       # % above contracted limit
        "tier2_max":  50,
        "hard_limit": 200,
    },
    "sla waiver": {
        "tier1_max":  7,        # days
        "tier2_max":  30,
        "hard_limit": 90,
    },
    "content access": {
        "tier1_max":  7,        # days
        "tier2_max":  30,
        "hard_limit": 90,
    },
    "kyc deferral": {
        "tier1_max":  14,       # days
        "tier2_max":  60,
        "hard_limit": 90,
    },
}

ALLOWED_TYPES = set(THRESHOLDS.keys())


def guardrail_node(state: DeviationState) -> DeviationState:
    """
    Validates the deviation request against policy thresholds.

    Rules checked (in order):
    1. Deviation type must be in the allowed list
    2. Requested value must be a positive number
    3. Requested value must not exceed the hard limit for that type
    4. Urgency must be a recognised value

    Sets:
        state["guardrail_passed"] = True/False
        state["guardrail_reason"] = explanation if blocked
        state["risk_level"]       = Low / Medium / High / Critical
    """

    dev_type  = state.get("deviation_type", "").lower().strip()
    req_val   = state.get("requested_value", 0)
    urgency   = state.get("urgency", "Medium")

    print(f"\n🛡️  [Guardrail Agent] Checking deviation: type='{dev_type}' value={req_val}")

    # ── Rule 1: Valid deviation type ──────────────────────────────────────────
    if dev_type not in ALLOWED_TYPES:
        reason = (
            f"Unknown deviation type '{dev_type}'. "
            f"Allowed types: {', '.join(ALLOWED_TYPES)}."
        )
        print(f"  ❌ BLOCKED — {reason}")
        return {
            **state,
            "guardrail_passed": False,
            "guardrail_reason": reason,
            "risk_level": "Critical"
        }

    thresholds = THRESHOLDS[dev_type]

    # ── Rule 2: Positive value ────────────────────────────────────────────────
    if req_val <= 0:
        reason = "Requested value must be greater than zero."
        print(f"  ❌ BLOCKED — {reason}")
        return {
            **state,
            "guardrail_passed": False,
            "guardrail_reason": reason,
            "risk_level": "High"
        }

    # ── Rule 3: Hard ceiling check ────────────────────────────────────────────
    if req_val > thresholds["hard_limit"]:
        reason = (
            f"Requested value {req_val} exceeds the absolute policy ceiling "
            f"of {thresholds['hard_limit']} for '{dev_type}'. "
            f"This deviation cannot be processed — escalate to Legal."
        )
        print(f"  ❌ BLOCKED — {reason}")
        return {
            **state,
            "guardrail_passed": False,
            "guardrail_reason": reason,
            "risk_level": "Critical"
        }

    # ── Rule 4: Valid urgency ─────────────────────────────────────────────────
    if urgency not in ("Low", "Medium", "High", "Critical"):
        reason = f"Invalid urgency '{urgency}'. Must be Low, Medium, High, or Critical."
        print(f"  ❌ BLOCKED — {reason}")
        return {
            **state,
            "guardrail_passed": False,
            "guardrail_reason": reason,
            "risk_level": "High"
        }

# backend/agents/guardrail.py
# Add these rules inside guardrail_node(), after Rule 4 and before the risk calculation

    # ── Rule 5: Scope must be provided ───────────────────────────────────────
    scope = state.get("scope", "").strip()
    if not scope or len(scope) < 10:
        reason = (
            "A business scope description is required (minimum 10 characters). "
            "Describe what the deviation covers and why it is needed."
        )
        print(f"  ❌ BLOCKED — {reason}")
        return {
            **state,
            "guardrail_passed": False,
            "guardrail_reason": reason,
            "risk_level": "High"
        }

    # ── Rule 6: Customer name must be provided ────────────────────────────────
    customer = state.get("customer_name", "").strip()
    if not customer or len(customer) < 2:
        reason = "A valid customer name is required."
        print(f"  ❌ BLOCKED — {reason}")
        return {
            **state,
            "guardrail_passed": False,
            "guardrail_reason": reason,
            "risk_level": "High"
        }

    # ── Rule 7: Requested value must not equal standard limit exactly ─────────
    # (A deviation that requests exactly the limit is not a deviation)
    std_limit = state.get("standard_limit", 0)
    if std_limit > 0 and req_val == std_limit:
        reason = (
            f"Requested value {req_val} equals the standard limit exactly. "
            "A deviation must request a value that differs from the standard limit."
        )
        print(f"  ❌ BLOCKED — {reason}")
        return {
            **state,
            "guardrail_passed": False,
            "guardrail_reason": reason,
            "risk_level": "Low"
        }

    # ── Rule 8: Critical urgency requires value above tier-1 threshold ────────
    # Prevents abuse of Critical urgency to fast-track trivial deviations
    if urgency == "Critical" and req_val <= thresholds["tier1_max"] * 0.1:
        reason = (
            f"Critical urgency is reserved for significant deviations. "
            f"Requested value {req_val} is too low to justify Critical urgency. "
            f"Please select High, Medium, or Low."
        )
        print(f"  ❌ BLOCKED — {reason}")
        return {
            **state,
            "guardrail_passed": False,
            "guardrail_reason": reason,
            "risk_level": "Low"
        }
    # ── Passed — compute risk level ───────────────────────────────────────────
    if req_val <= thresholds["tier1_max"]:
        risk = "Low"
    elif req_val <= thresholds["tier2_max"]:
        risk = "Medium"
    else:
        risk = "High"

    print(f"  ✅ PASSED — Risk level: {risk}")
    return {
        **state,
        "guardrail_passed": True,
        "guardrail_reason": "",
        "risk_level": risk
    }