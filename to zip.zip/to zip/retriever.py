# backend/rag/retriever.py

# ── SSL patch — must be FIRST ─────────────────────────────────────────────────
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_original_get = requests.get
def _patched_get(url, **kwargs):
    kwargs["verify"] = False
    return _original_get(url, **kwargs)
requests.get = _patched_get
# ── End SSL patch ─────────────────────────────────────────────────────────────

import os
import httpx
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma

CHROMA_DIR = os.path.join(os.path.dirname(__file__), "chroma_store")


def _load_vectorstore() -> Chroma:
    embedding_model = OpenAIEmbeddings(
        model="azure/genailab-maas-text-embedding-3-large",  # ← full name for LiteLLM routing
        openai_api_key=os.getenv("GENAI_API_KEY"),
        openai_api_base="https://genailab.tcs.in",
        openai_api_type="openai",
        chunk_size=100,
        tiktoken_model_name="cl100k_base",   # ← use base encoding name, already cached locally
        http_client=httpx.Client(verify=False),
        http_async_client=httpx.AsyncClient(verify=False)
    )

    return Chroma(
        persist_directory=CHROMA_DIR,
        embedding_function=embedding_model,
        collection_name="telcoflow_policies"
    )


_vectorstore = _load_vectorstore()


def retrieve(query: str, k: int = 4) -> list[dict]:
    results = _vectorstore.similarity_search_with_score(query, k=k)
    return [
        {
            "content": doc.page_content,
            "source":  doc.metadata.get("source", "unknown"),
            "score":   round(score, 4)
        }
        for doc, score in results
    ]


def retrieve_as_context(query: str, k: int = 4) -> str:
    results = retrieve(query, k=k)
    if not results:
        return "No relevant policy clauses found."
    return "\n\n---\n\n".join(
        f"[SOURCE: {r['source']}]\n{r['content']}" for r in results
    )