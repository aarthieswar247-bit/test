# backend/agents/advisor.py

import os
import sys
import httpx
import urllib3

# SSL patch — must be first
import requests as _requests
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
_orig_get = _requests.get
def _patched_get(url, **kwargs):
    kwargs["verify"] = False
    return _orig_get(url, **kwargs)
_requests.get = _patched_get

from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from rag.retriever import retrieve_as_context


# ── Shared approval workflow state ────────────────────────────────────────────
# This is a separate state from DeviationState — used only by the approval graph

from typing import TypedDict, Optional, List


class ApprovalWorkflowState(TypedDict):
    # Deviation context (loaded at start)
    deviation_id:       str
    deviation_type:     str
    customer_name:      str
    requested_value:    float
    standard_limit:     float
    scope:              str
    urgency:            str
    risk_level:         str
    ai_justification:   str
    policy_refs:        str

    # Approval chain tracking
    current_step_index: int          # 0=Ops, 1=Finance, 2=Network, 3=Compliance
    current_step_id:    int          # DB row ID of the current approval_steps row
    current_role:       str          # ops, finance, network, compliance
    current_label:      str          # Operations, Finance, Network, Compliance

    # Human decision (set when human acts)
    human_action:       Optional[str]   # "approve" or "reject"
    human_actor:        Optional[str]   # username
    human_comment:      Optional[str]   # their comment

    # AI advisor output for current step
    ai_suggestion:      str

    # Final outcome
    workflow_status:    str          # running, approved, rejected
    rejection_reason:   Optional[str]

    # Audit trail within the graph
    decisions:          List[dict]   # list of {step, role, action, actor, comment}


def get_llm():
    return ChatOpenAI(
        model="azure/genailab-maas-gpt-4.1",
        api_key=os.getenv("GENAI_API_KEY"),
        base_url="https://genailab.tcs.in",
        http_client=httpx.Client(verify=False),
        http_async_client=httpx.AsyncClient(verify=False),
        temperature=0.2,
        max_tokens=300
    )


# Role-specific advisor instructions
ROLE_ADVISOR_PROMPTS = {
    "ops": (
        "You are advising the Operations team. Focus on: "
        "operational feasibility, incident validity, "
        "and whether the deviation is technically justified."
    ),
    "finance": (
        "You are advising the Finance team. Focus on: "
        "financial impact, credit thresholds, revenue implications, "
        "and whether the amount is within policy limits."
    ),
    "network": (
        "You are advising the Network team. Focus on: "
        "technical validity, bandwidth or SLA impact, "
        "network telemetry evidence, and infrastructure risk."
    ),
    "compliance": (
        "You are advising the Compliance team. Focus on: "
        "regulatory compliance, audit trail completeness, "
        "GDPR/FCC/CPUC obligations, and legal risk."
    )
}


def advisor_node(state: ApprovalWorkflowState) -> ApprovalWorkflowState:
    """
    Generates a role-specific AI recommendation for the current approval step.
    Runs BEFORE the human-in-the-loop interrupt at each step.

    Sets:
        state["ai_suggestion"] = the AI recommendation text for this role
    """
    role  = state["current_role"]
    label = state["current_label"]

    print(f"\n⚖️  [Advisor Agent] Generating recommendation for {label} role...")

    # Build RAG query specific to the current role's concerns
    rag_query = (
        f"{state['deviation_type']} {state['scope']} "
        f"{role} approval policy threshold compliance"
    )
    policy_context = retrieve_as_context(rag_query, k=3)

    role_instruction = ROLE_ADVISOR_PROMPTS.get(role, "You are advising an approver.")

    user_prompt = f"""You are providing a decision recommendation to the {label} approver.

{role_instruction}

DEVIATION SUMMARY:
- Type: {state['deviation_type']}
- Customer: {state['customer_name']}
- Requested Value: {state['requested_value']}
- Standard Limit: {state['standard_limit']}
- Risk Level: {state['risk_level']}
- Scope: {state['scope']}
- Urgency: {state['urgency']}

BUSINESS JUSTIFICATION (AI-generated):
{state['ai_justification'][:400]}

RELEVANT POLICY CONTEXT:
{policy_context[:600]}

Provide a 2-3 sentence recommendation for the {label} approver.
End with: "Recommendation: Approve / Reject / Escalate" on its own line."""

    try:
        llm = get_llm()
        messages = [
            SystemMessage(content=f"You are a compliance advisor for a Telecom/Media company. {role_instruction}"),
            HumanMessage(content=user_prompt)
        ]
        response = llm.invoke(messages)
        suggestion = response.content.strip()
        print(f"  ✅ Advisor recommendation generated for {label}")

    except Exception as e:
        print(f"  ⚠️  Advisor LLM failed: {e} — using fallback")
        suggestion = (
            f"AI advisor unavailable. Manual review required for {label} step. "
            f"Risk level: {state['risk_level']}. "
            f"Recommendation: Review policy documents before deciding."
        )

    return {**state, "ai_suggestion": suggestion}