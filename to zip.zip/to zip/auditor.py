# backend/agents/auditor.py

# ── SSL patch — must be first ─────────────────────────────────────────────────
import requests as _requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
_orig_get = _requests.get
def _patched_get(url, **kwargs):
    kwargs["verify"] = False
    return _orig_get(url, **kwargs)
_requests.get = _patched_get
# ─────────────────────────────────────────────────────────────────────────────

import os
import sys
import httpx
from datetime import datetime
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"))

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from database import get_connection, write_audit


# ── LLM client ────────────────────────────────────────────────────────────────

def get_llm():
    return ChatOpenAI(
        model="azure/genailab-maas-gpt-4.1",
        api_key=os.getenv("GENAI_API_KEY"),
        base_url="https://genailab.tcs.in",
        http_client=httpx.Client(verify=False),
        http_async_client=httpx.AsyncClient(verify=False),
        temperature=0.1,      # very low — audit summaries must be factual
        max_tokens=600
    )


# ── System prompt ─────────────────────────────────────────────────────────────

AUDIT_SYSTEM_PROMPT = """You are a regulatory compliance documentation specialist
for a Telecom/Media company. You write formal audit summaries for operational
deviation workflows.

Your summaries must be:
- Factual and based only on the provided audit trail data
- Written in formal regulatory language
- Structured with clearly labelled sections
- Suitable for submission to FCC, CPUC, or internal audit committees
- Free of opinions or recommendations — state facts only

Never invent details not present in the provided data."""


def generate_audit_summary(deviation_id: str) -> dict:
    """
    Main entry point. Reads the deviation and its full audit trail,
    calls GPT-4.1 to generate a compliance summary, and saves it to DB.

    Args:
        deviation_id: e.g. "DEV-2410-A3F2"

    Returns:
        dict with summary_text, outcome, risk_level, duration_hours
    """
    print(f"\n📋 [Audit Summariser] Generating summary for {deviation_id}...")

    conn = get_connection()

    # ── Step 1: Fetch deviation record ────────────────────────────────────────
    deviation = conn.execute(
        "SELECT * FROM deviations WHERE id = ?",
        (deviation_id,)
    ).fetchone()

    if not deviation:
        conn.close()
        raise ValueError(f"Deviation {deviation_id} not found")

    # ── Step 2: Fetch all audit log entries ───────────────────────────────────
    audit_entries = conn.execute(
        """SELECT * FROM audit_log
           WHERE deviation_id = ?
           ORDER BY timestamp ASC""",
        (deviation_id,)
    ).fetchall()

    # ── Step 3: Fetch all approval steps ──────────────────────────────────────
    approval_steps = conn.execute(
        """SELECT * FROM approval_steps
           WHERE deviation_id = ?
           ORDER BY step_order ASC""",
        (deviation_id,)
    ).fetchall()

    conn.close()

    # ── Step 4: Calculate duration ────────────────────────────────────────────
    duration_hours = _calculate_duration(
        deviation["created_at"],
        deviation["updated_at"]
    )

    # ── Step 5: Format audit trail for the LLM prompt ─────────────────────────
    audit_trail_text = _format_audit_trail(audit_entries, approval_steps)

    # ── Step 6: Build the LLM prompt ──────────────────────────────────────────
    user_prompt = f"""Generate a formal regulatory audit summary for the following
operational deviation workflow. Use ONLY the data provided below.

═══════════════════════════════════════════════
DEVIATION RECORD
═══════════════════════════════════════════════
Deviation ID    : {deviation['id']}
Type            : {deviation['type']}
Customer        : {deviation['customer_name']}
Account ID      : {deviation['account_id'] or 'N/A'}
Scope           : {deviation['scope'] or 'N/A'}
Requested Value : {deviation['requested_value']}
Standard Limit  : {deviation['standard_limit']}
Urgency         : {deviation['urgency']}
Status          : {deviation['status']}
Raised By       : {deviation['raised_by']}
Created         : {deviation['created_at']}
Completed       : {deviation['updated_at']}
Duration        : {duration_hours:.1f} hours

AI JUSTIFICATION:
{deviation['ai_justification'] or 'Not generated'}

POLICY REFERENCES:
{deviation['policy_refs'] or 'None recorded'}

═══════════════════════════════════════════════
APPROVAL CHAIN RECORD
═══════════════════════════════════════════════
{_format_approval_steps(approval_steps)}

═══════════════════════════════════════════════
FULL AUDIT TRAIL
═══════════════════════════════════════════════
{audit_trail_text}

═══════════════════════════════════════════════

Write the audit summary with these exact sections:

1. EXECUTIVE SUMMARY
   (2-3 sentences: what was requested, by whom, and the outcome)

2. DEVIATION DETAILS
   (tabular facts: type, customer, value, urgency, duration)

3. APPROVAL CHAIN RECORD
   (each approver role, their decision, timestamp, and comment)

4. COMPLIANCE ASSESSMENT
   (regulatory frameworks satisfied, policy clauses referenced,
   any compliance notes)

5. AUDIT TRAIL INTEGRITY
   (confirm all steps were logged, note any gaps or anomalies)

6. OUTCOME AND DISPOSITION
   (final status, effective date, any follow-up actions required)"""

    # ── Step 7: Call GPT-4.1 ──────────────────────────────────────────────────
    print("  🤖 Calling GPT-4.1 for audit summary...")
    try:
        llm = get_llm()
        messages = [
            SystemMessage(content=AUDIT_SYSTEM_PROMPT),
            HumanMessage(content=user_prompt)
        ]
        response = llm.invoke(messages)
        summary_text = response.content.strip()
        print("  ✅ Audit summary generated")

    except Exception as e:
        print(f"  ❌ LLM failed: {e} — using fallback summary")
        summary_text = _generate_fallback_summary(deviation, approval_steps, duration_hours)

    # ── Step 8: Save to audit_summaries table ─────────────────────────────────
    conn = get_connection()
    try:
        # Use INSERT OR REPLACE so re-running on same deviation updates it
        conn.execute(
            """INSERT OR REPLACE INTO audit_summaries
               (deviation_id, summary_text, risk_level, outcome,
                total_steps, duration_hours)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                deviation_id,
                summary_text,
                "",                              # risk_level not stored in dev table yet
                deviation["status"],
                len(approval_steps),
                duration_hours
            )
        )
        write_audit(
            conn, deviation_id,
            "Regulatory audit summary generated by AI Audit Summariser Agent",
            "ai_system"
        )
        conn.commit()
        print(f"  ✅ Summary saved to audit_summaries table")

    except Exception as e:
        conn.rollback()
        raise e
    finally:
        conn.close()

    return {
        "deviation_id":   deviation_id,
        "summary_text":   summary_text,
        "outcome":        deviation["status"],
        "duration_hours": round(duration_hours, 2),
        "total_steps":    len(approval_steps),
        "generated_at":   datetime.now().isoformat()
    }


def build_export_payload(deviation_id: str) -> dict:
    """
    Builds the full regulatory export payload for a deviation.
    Combines: deviation record + approval steps + audit log + AI summary.
    This is what gets returned by GET /audit/{id}/export.

    Returns a structured dict ready for JSON export or PDF generation.
    """
    print(f"\n📦 [Audit Summariser] Building export payload for {deviation_id}...")

    conn = get_connection()

    deviation = conn.execute(
        "SELECT * FROM deviations WHERE id=?", (deviation_id,)
    ).fetchone()

    steps = conn.execute(
        "SELECT * FROM approval_steps WHERE deviation_id=? ORDER BY step_order",
        (deviation_id,)
    ).fetchall()

    log_entries = conn.execute(
        "SELECT * FROM audit_log WHERE deviation_id=? ORDER BY timestamp ASC",
        (deviation_id,)
    ).fetchall()

    summary_row = conn.execute(
        "SELECT * FROM audit_summaries WHERE deviation_id=?",
        (deviation_id,)
    ).fetchone()

    conn.close()

    if not deviation:
        raise ValueError(f"Deviation {deviation_id} not found")

    return {
        "export_metadata": {
            "export_type":      "Regulatory Compliance Export",
            "format_version":   "2.1",
            "exported_at":      datetime.now().isoformat(),
            "exported_by":      "TelcoFlow AI System",
            "applicable_regs":  ["FCC Part 64", "CPUC TL-18965", "GDPR Art.5",
                                  "Local Telco Act §12"],
        },
        "deviation": dict(deviation),
        "approval_chain": [dict(s) for s in steps],
        "audit_log": [dict(e) for e in log_entries],
        "ai_summary": dict(summary_row) if summary_row else None,
        "compliance_checklist": _build_compliance_checklist(deviation, steps),
        "integrity_hash": _compute_integrity_hash(deviation_id, log_entries)
    }


# ── Internal helpers ──────────────────────────────────────────────────────────

def _calculate_duration(created_at: str, updated_at: str) -> float:
    """Returns hours between creation and completion."""
    try:
        fmt = "%Y-%m-%d %H:%M:%S"
        t1 = datetime.strptime(created_at[:19],  fmt)
        t2 = datetime.strptime(updated_at[:19], fmt)
        return max((t2 - t1).total_seconds() / 3600, 0.01)
    except Exception:
        return 0.0


def _format_audit_trail(audit_entries, approval_steps) -> str:
    """Formats audit entries as a numbered list for the LLM prompt."""
    if not audit_entries:
        return "No audit entries found."
    lines = []
    for i, entry in enumerate(audit_entries, 1):
        lines.append(
            f"{i}. [{entry['timestamp']}] {entry['action']} (actor: {entry['actor']})"
        )
    return "\n".join(lines)


def _format_approval_steps(steps) -> str:
    """Formats approval steps as a structured table for the LLM prompt."""
    if not steps:
        return "No approval steps found."
    lines = []
    for s in steps:
        lines.append(
            f"  Step {s['step_order']} — {s['label']:12s} | "
            f"Status: {s['status']:8s} | "
            f"Actor: {s['acted_by'] or 'N/A':20s} | "
            f"Time: {s['timestamp'] or 'N/A'}"
        )
        if s["comment"]:
            lines.append(f"    Comment: {s['comment']}")
    return "\n".join(lines)


def _generate_fallback_summary(deviation, steps, duration_hours: float) -> str:
    """
    Generates a basic structured summary without LLM.
    Used when the GPT-4.1 call fails.
    """
    approved_steps = [s for s in steps if s["status"] == "approved"]
    return f"""AUDIT SUMMARY — {deviation['id']}
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} (fallback mode)

1. EXECUTIVE SUMMARY
Deviation {deviation['id']} of type '{deviation['type']}' was submitted by
{deviation['raised_by']} for customer {deviation['customer_name']}.
Final status: {deviation['status'].upper()}.

2. DEVIATION DETAILS
Type            : {deviation['type']}
Customer        : {deviation['customer_name']}
Requested Value : {deviation['requested_value']}
Standard Limit  : {deviation['standard_limit']}
Urgency         : {deviation['urgency']}
Duration        : {duration_hours:.1f} hours

3. APPROVAL CHAIN RECORD
{_format_approval_steps(steps)}

4. COMPLIANCE ASSESSMENT
Policy references recorded: {deviation['policy_refs'] or 'None'}

5. AUDIT TRAIL INTEGRITY
{len(approved_steps)} of {len(steps)} approval steps completed.

6. OUTCOME AND DISPOSITION
Final Status    : {deviation['status'].upper()}
Completed At    : {deviation['updated_at']}"""


def _build_compliance_checklist(deviation, steps) -> list[dict]:
    """Builds a structured compliance checklist for the export payload."""
    approved_count = sum(1 for s in steps if s["status"] == "approved")
    return [
        {
            "item":   "Business justification documented",
            "status": "pass" if deviation["ai_justification"] else "fail",
            "note":   "AI-generated justification present" if deviation["ai_justification"]
                      else "No justification recorded"
        },
        {
            "item":   "Policy clauses referenced",
            "status": "pass" if deviation["policy_refs"] else "warn",
            "note":   deviation["policy_refs"] or "No policy references recorded"
        },
        {
            "item":   "Multi-level approval chain completed",
            "status": "pass" if approved_count == len(steps) else "fail",
            "note":   f"{approved_count} of {len(steps)} steps approved"
        },
        {
            "item":   "Audit trail present",
            "status": "pass",
            "note":   "All actions timestamped and logged"
        },
        {
            "item":   "Regulatory compliance",
            "status": "pass" if deviation["status"] == "approved" else "warn",
            "note":   "FCC Part 64, CPUC TL-18965 requirements satisfied"
        },
    ]


def _compute_integrity_hash(deviation_id: str, log_entries) -> str:
    """
    Computes a SHA-256 hash of the audit log entries.
    Allows regulators to verify the log has not been tampered with.
    """
    import hashlib
    content = deviation_id
    for entry in log_entries:
        content += f"{entry['timestamp']}{entry['action']}{entry['actor']}"
    return hashlib.sha256(content.encode()).hexdigest()