# backend/test_e2e.py
# End-to-end integration test — runs the full workflow via real HTTP calls.
# No extra test framework needed — just Python's built-in unittest.
#
# Prerequisites:
#   1. uvicorn must be running on port 8000
#   2. RAG must be ingested (rag/ingest.py already run)
#
# Run:  python test_e2e.py

import unittest
import requests
import time

BASE = "http://127.0.0.1:8000"
S    = requests.Session()
S.verify = False


def log(msg): print(f"\n{'─'*55}\n{msg}\n{'─'*55}")


class TelcoFlowE2ETest(unittest.TestCase):

    dev_id = None   # shared across test methods

    # ── Test 1: Health check ──────────────────────────────────────────────────
    def test_01_health(self):
        log("TEST 1 — Health check")
        r = S.get(f"{BASE}/health")
        self.assertEqual(r.status_code, 200)
        data = r.json()
        self.assertIn("status", data)
        self.assertEqual(data["subsystems"]["database"], "ok")
        print(f"  ✅ Health: {data['status']}")
        print(f"  Subsystems: {data['subsystems']}")

    # ── Test 2: Create deviation ──────────────────────────────────────────────
    def test_02_create_deviation(self):
        log("TEST 2 — Create deviation")
        payload = {
            "type":            "billing credit",
            "customer_name":   "GlobalTel Media Inc.",
            "account_id":      "ACC-10042",
            "scope":           "Overcharge on bandwidth burst usage during network upgrade",
            "requested_value": 12450,
            "standard_limit":  15000,
            "urgency":         "High",
            "raised_by":       "ops_user"
        }
        r = S.post(f"{BASE}/deviations/", json=payload)
        self.assertEqual(r.status_code, 201, r.text)
        data = r.json()
        self.assertIn("id", data)
        self.assertEqual(data["status"], "draft")
        TelcoFlowE2ETest.dev_id = data["id"]
        print(f"  ✅ Created: {data['id']}")

    # ── Test 3: Guardrail blocks invalid type ─────────────────────────────────
    def test_03_guardrail_blocks_invalid_type(self):
        log("TEST 3 — Guardrail: invalid deviation type")
        payload = {
            "type":            "invalid_type",
            "customer_name":   "Test Corp",
            "scope":           "Testing invalid type rejection",
            "requested_value": 1000,
            "standard_limit":  2000,
            "urgency":         "Low",
            "raised_by":       "ops_user"
        }
        r = S.post(f"{BASE}/deviations/", json=payload)
        self.assertEqual(r.status_code, 422)
        print(f"  ✅ Blocked with 422 — {r.json()['detail']}")

    # ── Test 4: Guardrail blocks value over ceiling ───────────────────────────
    def test_04_guardrail_blocks_ceiling(self):
        log("TEST 4 — Guardrail: value exceeds hard ceiling")
        payload = {
            "type":            "billing credit",
            "customer_name":   "Test Corp",
            "scope":           "Testing hard ceiling rejection threshold",
            "requested_value": 150000,
            "standard_limit":  15000,
            "urgency":         "High",
            "raised_by":       "ops_user"
        }
        r = S.post(f"{BASE}/deviations/", json=payload)
        self.assertEqual(r.status_code, 422)
        print(f"  ✅ Blocked with 422 — {r.json()['detail']}")

    # ── Test 5: AI analysis ───────────────────────────────────────────────────
    def test_05_analyse(self):
        log("TEST 5 — AI analysis (guardrail + justification agents)")
        self.assertIsNotNone(self.dev_id, "Run test_02 first")
        r = S.post(f"{BASE}/deviations/{self.dev_id}/analyse")
        self.assertEqual(r.status_code, 200, r.text)
        data = r.json()
        self.assertTrue(data["guardrail_passed"])
        self.assertIn(data["risk_level"], ["Low", "Medium", "High"])
        self.assertGreater(len(data["ai_justification"]), 50)
        print(f"  ✅ Guardrail passed — Risk: {data['risk_level']}")
        print(f"  Justification preview: {data['ai_justification'][:120]}...")

    # ── Test 6: Submit for approval ───────────────────────────────────────────
    def test_06_submit(self):
        log("TEST 6 — Submit deviation")
        self.assertIsNotNone(self.dev_id)
        r = S.post(f"{BASE}/deviations/{self.dev_id}/submit",
                   params={"actor": "ops_user"})
        self.assertEqual(r.status_code, 200, r.text)
        self.assertEqual(r.json()["status"], "in_review")
        print(f"  ✅ Submitted — status: in_review")

    # ── Test 7: Cannot double-submit ──────────────────────────────────────────
    def test_07_no_double_submit(self):
        log("TEST 7 — Guardrail: cannot re-submit an in_review deviation")
        self.assertIsNotNone(self.dev_id)
        r = S.post(f"{BASE}/deviations/{self.dev_id}/submit",
                   params={"actor": "ops_user"})
        self.assertEqual(r.status_code, 409)
        print(f"  ✅ Blocked with 409 — {r.json()['detail']}")

    # ── Test 8: Start workflow ────────────────────────────────────────────────
    def test_08_start_workflow(self):
        log("TEST 8 — Start LangGraph approval workflow")
        self.assertIsNotNone(self.dev_id)
        r = S.post(f"{BASE}/approvals/workflow/start/{self.dev_id}")
        self.assertEqual(r.status_code, 200, r.text)
        data = r.json()
        self.assertEqual(data["workflow_status"], "waiting_for_approval")
        self.assertEqual(data["waiting_for"], "Operations")
        self.assertIsNotNone(data["ai_suggestion"])
        print(f"  ✅ Workflow started — waiting for: {data['waiting_for']}")
        print(f"  AI suggestion preview: {data['ai_suggestion'][:100]}...")

    # ── Test 9: Full 4-step approval chain ────────────────────────────────────
    def test_09_full_approval_chain(self):
        log("TEST 9 — Full approval chain (Ops → Finance → Network → Compliance)")
        self.assertIsNotNone(self.dev_id)

        steps = [
            ("ops_user",        "Operations", "Valid incident confirmed. Approve."),
            ("finance_user",    "Finance",    "Within Tier-2 limit. Approved."),
            ("network_user",    "Network",    "Telemetry confirms metering error."),
            ("compliance_user", "Compliance", "Regulatory review passed. GDPR compliant."),
        ]

        for actor, expected_role, comment in steps:
            print(f"\n  Processing: {expected_role} approval by {actor}...")
            r = S.post(
                f"{BASE}/approvals/workflow/resume/{self.dev_id}",
                json={"action": "approve", "actor": actor, "comment": comment}
            )
            self.assertEqual(r.status_code, 200, f"{expected_role} step failed: {r.text}")
            data = r.json()
            print(f"  ✅ {expected_role} approved — status: {data['workflow_status']}")
            time.sleep(0.5)   # small delay between steps

        # Final status should be approved
        self.assertEqual(data["workflow_status"], "approved")
        print(f"\n  🎉 Deviation fully approved!")

    # ── Test 10: Verify DB status ─────────────────────────────────────────────
    def test_10_verify_deviation_status(self):
        log("TEST 10 — Verify deviation status in DB")
        self.assertIsNotNone(self.dev_id)
        r = S.get(f"{BASE}/deviations/{self.dev_id}")
        self.assertEqual(r.status_code, 200)
        data = r.json()
        self.assertEqual(data["deviation"]["status"], "approved")
        queue = data["approval_queue"]
        self.assertEqual(len(queue), 4)
        for step in queue:
            self.assertEqual(step["status"], "approved",
                f"Step {step['label']} is not approved")
        print(f"  ✅ Deviation status: approved")
        print(f"  ✅ All 4 approval steps: approved")

    # ── Test 11: Audit log populated ─────────────────────────────────────────
    def test_11_audit_log(self):
        log("TEST 11 — Audit log integrity")
        self.assertIsNotNone(self.dev_id)
        r = S.get(f"{BASE}/audit/{self.dev_id}/log")
        self.assertEqual(r.status_code, 200)
        entries = r.json()
        self.assertGreater(len(entries), 5, "Expected at least 6 audit entries")
        actors = {e["actor"] for e in entries}
        print(f"  ✅ {len(entries)} audit entries found")
        print(f"  Actors recorded: {actors}")

    # ── Test 12: AI audit summary ─────────────────────────────────────────────
    def test_12_audit_summary(self):
        log("TEST 12 — AI audit summary generation")
        self.assertIsNotNone(self.dev_id)
        r = S.post(f"{BASE}/audit/{self.dev_id}/summarise")
        self.assertEqual(r.status_code, 200, r.text)
        data = r.json()
        self.assertIn("summary_text", data)
        self.assertGreater(len(data["summary_text"]), 100)
        self.assertEqual(data["outcome"], "approved")
        print(f"  ✅ Summary generated ({len(data['summary_text'])} chars)")
        print(f"  Preview: {data['summary_text'][:200]}...")

    # ── Test 13: Regulatory export ────────────────────────────────────────────
    def test_13_export(self):
        log("TEST 13 — Regulatory export payload")
        self.assertIsNotNone(self.dev_id)
        r = S.get(f"{BASE}/audit/{self.dev_id}/export")
        self.assertEqual(r.status_code, 200, r.text)
        data = r.json()
        self.assertIn("export_metadata",     data)
        self.assertIn("deviation",           data)
        self.assertIn("approval_chain",      data)
        self.assertIn("audit_log",           data)
        self.assertIn("compliance_checklist",data)
        self.assertIn("integrity_hash",      data)
        checklist = data["compliance_checklist"]
        passed = [c for c in checklist if c["status"] == "pass"]
        print(f"  ✅ Export payload complete")
        print(f"  Compliance checklist: {len(passed)}/{len(checklist)} passed")
        print(f"  Integrity hash: {data['integrity_hash'][:32]}...")

    # ── Test 14: Role-based access enforcement ────────────────────────────────
    def test_14_role_enforcement(self):
        log("TEST 14 — Role enforcement: wrong role cannot approve")

        # Create a fresh deviation and submit it
        payload = {
            "type":            "sla waiver",
            "customer_name":   "TestCorp Ltd",
            "scope":           "SLA waiver for planned maintenance window test",
            "requested_value": 5,
            "standard_limit":  7,
            "urgency":         "Medium",
            "raised_by":       "ops_user"
        }
        r = S.post(f"{BASE}/deviations/", json=payload)
        dev_id = r.json()["id"]

        S.post(f"{BASE}/deviations/{dev_id}/analyse")
        S.post(f"{BASE}/deviations/{dev_id}/submit", params={"actor": "ops_user"})
        S.post(f"{BASE}/approvals/workflow/start/{dev_id}")

        # Try to approve Ops step as Finance user — should be blocked
        r = S.post(
            f"{BASE}/approvals/workflow/resume/{dev_id}",
            json={
                "action":  "approve",
                "actor":   "finance_user",   # wrong role for Ops step
                "comment": "Attempting to approve wrong step"
            }
        )
        self.assertEqual(r.status_code, 403,
            f"Expected 403 Forbidden but got {r.status_code}")
        print(f"  ✅ Role enforcement working — finance_user blocked from Ops step")
        print(f"  Response: {r.json()['detail']}")


if __name__ == "__main__":
    import urllib3
    urllib3.disable_warnings()

    print("\n" + "="*55)
    print("  TelcoFlow AI — End-to-End Integration Tests")
    print("="*55)
    print("  Make sure uvicorn is running on port 8000")
    print("="*55)

    unittest.main(verbosity=0, exit=True)