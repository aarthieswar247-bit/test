# backend/agents/graph.py

from langgraph.graph import StateGraph, END
from agents.guardrail     import DeviationState, guardrail_node
from agents.justification import justification_node


def route_after_guardrail(state: DeviationState) -> str:
    """
    Conditional edge function.
    LangGraph calls this after guardrail_node runs to decide the next node.

    Returns:
        "justification" → if guardrail passed
        "blocked"       → if guardrail failed (goes straight to END)
    """
    if state.get("guardrail_passed"):
        return "justification"
    return "blocked"


def build_analysis_graph() -> StateGraph:
    """
    Builds and compiles the Phase 4 analysis graph.

    Graph structure:
        START → guardrail_node
                     │
          ┌──────────┴───────────┐
          │                      │
       (blocked)            (justification)
          │                      │
         END         justification_node → END
    """

    # Create the graph with our shared state type
    graph = StateGraph(DeviationState)

    # Register nodes — each is a function that takes State and returns State
    graph.add_node("guardrail",     guardrail_node)
    graph.add_node("justification", justification_node)

    # Entry point — always start at guardrail
    graph.set_entry_point("guardrail")

    # Conditional edge after guardrail
    graph.add_conditional_edges(
        "guardrail",            # from this node
        route_after_guardrail,  # call this function to decide
        {
            "justification": "justification",   # if returns "justification" → go here
            "blocked":       END                # if returns "blocked" → stop
        }
    )

    # After justification, always end
    graph.add_edge("justification", END)

    # Compile turns the graph definition into a runnable object
    return graph.compile()


# Build once at import time — reused across all API requests
analysis_graph = build_analysis_graph()


def run_analysis(deviation_data: dict) -> DeviationState:
    """
    Entry point called by the FastAPI endpoint.
    Converts the deviation dict into a DeviationState and runs the graph.

    Args:
        deviation_data: dict from the deviations DB row

    Returns:
        Final DeviationState after all nodes have run
    """

    # Build the initial state from the deviation data
    initial_state: DeviationState = {
        "deviation_id":     deviation_data.get("id", ""),
        "deviation_type":   deviation_data.get("type", ""),
        "customer_name":    deviation_data.get("customer_name", ""),
        "requested_value":  float(deviation_data.get("requested_value") or 0),
        "standard_limit":   float(deviation_data.get("standard_limit") or 0),
        "urgency":          deviation_data.get("urgency", "Medium"),
        "scope":            deviation_data.get("scope", ""),
        "raised_by":        deviation_data.get("raised_by", ""),
        # Output fields — blank until agents fill them
        "guardrail_passed":  False,
        "guardrail_reason":  "",
        "risk_level":        "",
        "ai_justification":  "",
        "policy_refs":       "",
        "retrieved_context": "",
        "error":             None
    }

    print(f"\n{'='*55}")
    print(f"🚀 Running analysis graph for {deviation_data.get('id')}")
    print(f"{'='*55}")

    # .invoke() runs the full graph synchronously and returns the final state
    final_state = analysis_graph.invoke(initial_state)

    print(f"\n{'='*55}")
    print(f"✅ Graph complete — guardrail_passed={final_state['guardrail_passed']}")
    print(f"{'='*55}\n")

    return final_state