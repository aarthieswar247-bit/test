# backend/routers/deviations.py

from fastapi import APIRouter, HTTPException
from database import get_connection, generate_deviation_id, write_audit
from models import DeviationCreate, DeviationResponse
# At the top of routers/deviations.py — add alongside existing imports
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

router = APIRouter(prefix="/deviations", tags=["Deviations"])

# Allowed deviation types — used for validation (guardrail before Phase 4 AI)
ALLOWED_TYPES = {
    "billing credit",
    "bandwidth",
    "sla waiver",
    "content access",
    "kyc deferral"
}

# Default approval chain: every deviation goes through these 4 roles in order
APPROVAL_CHAIN = [
    (1, "ops",        "Operations"),
    (2, "finance",    "Finance"),
    (3, "network",    "Network"),
    (4, "compliance", "Compliance"),
]


# ── POST /deviations ──────────────────────────────────────────────────────────

@router.post("/", response_model=DeviationResponse, status_code=201)
def create_deviation(payload: DeviationCreate):
    """
    Creates a new deviation in 'draft' status.
    Does NOT trigger the approval queue yet — that happens on /submit.
    """

    # Basic guardrail: reject unknown deviation types
    if payload.type.lower() not in ALLOWED_TYPES:
        raise HTTPException(
            status_code=422,
            detail=f"Invalid deviation type '{payload.type}'. "
                   f"Allowed: {', '.join(ALLOWED_TYPES)}"
        )

    # Basic guardrail: requested value must not exceed absolute hard ceiling
    HARD_CEILING = 100_000
    if payload.requested_value and payload.requested_value > HARD_CEILING:
        raise HTTPException(
            status_code=422,
            detail=f"Requested value ${payload.requested_value:,.2f} exceeds "
                   f"the absolute system ceiling of ${HARD_CEILING:,.2f}."
        )

    dev_id = generate_deviation_id()
    conn = get_connection()

    try:
        conn.execute(
            """
            INSERT INTO deviations
              (id, type, customer_name, account_id, scope,
               requested_value, standard_limit, urgency,
               expiry_date, status, raised_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'draft', ?)
            """,
            (
                dev_id,
                payload.type.lower(),
                payload.customer_name,
                payload.account_id,
                payload.scope,
                payload.requested_value,
                payload.standard_limit,
                payload.urgency,
                payload.expiry_date,
                payload.raised_by,
            )
        )

        # Write the first audit entry
        write_audit(conn, dev_id, "Deviation draft created", payload.raised_by)
        conn.commit()

    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()

    # Fetch and return the newly created row
    return _fetch_deviation(dev_id)


# ── GET /deviations ───────────────────────────────────────────────────────────

@router.get("/", response_model=list[DeviationResponse])
def list_deviations(status: str = None, raised_by: str = None):
    """
    Returns all deviations.
    Optional query params: ?status=in_review  or  ?raised_by=ops_user
    Example: GET /deviations?status=in_review
    """
    conn = get_connection()
    query = "SELECT * FROM deviations WHERE 1=1"
    params = []

    if status:
        query += " AND status = ?"
        params.append(status)
    if raised_by:
        query += " AND raised_by = ?"
        params.append(raised_by)

    query += " ORDER BY created_at DESC"
    rows = conn.execute(query, params).fetchall()
    conn.close()

    # sqlite3.Row behaves like a dict — convert each to a plain dict
    return [dict(row) for row in rows]


# ── GET /deviations/{id} ──────────────────────────────────────────────────────

@router.get("/{deviation_id}")
def get_deviation(deviation_id: str):
    """
    Returns one deviation plus its full approval queue steps.
    This is the main payload the frontend loads when opening a deviation.
    """
    deviation = _fetch_deviation(deviation_id)
    if not deviation:
        raise HTTPException(status_code=404, detail=f"Deviation {deviation_id} not found")

    conn = get_connection()
    steps = conn.execute(
        "SELECT * FROM approval_steps WHERE deviation_id = ? ORDER BY step_order",
        (deviation_id,)
    ).fetchall()
    conn.close()

    return {
        "deviation": deviation,
        "approval_queue": [dict(s) for s in steps]
    }


# ── POST /deviations/{id}/submit ──────────────────────────────────────────────

@router.post("/{deviation_id}/submit")
def submit_deviation(deviation_id: str, actor: str):
    """
    Moves a deviation from 'draft' → 'in_review'.
    Creates the 4 sequential approval_steps rows.
    Sets step 1 (Operations) to 'pending'; rest stay 'waiting'.

    Usage: POST /deviations/DEV-2410-A3F2/submit?actor=ops_user
    """
    conn = get_connection()

    # Check deviation exists and is still a draft
    row = conn.execute(
        "SELECT * FROM deviations WHERE id = ?", (deviation_id,)
    ).fetchone()

    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="Deviation not found")

    if row["status"] != "draft":
        conn.close()
        raise HTTPException(
            status_code=409,
            detail=f"Deviation is already '{row['status']}' — cannot re-submit."
        )

    try:
        # Update deviation status
        conn.execute(
            "UPDATE deviations SET status='in_review', updated_at=datetime('now') WHERE id=?",
            (deviation_id,)
        )

        # Create the 4 approval steps
        for order, role, label in APPROVAL_CHAIN:
            status = "pending" if order == 1 else "waiting"
            conn.execute(
                """
                INSERT INTO approval_steps
                  (deviation_id, step_order, role_required, label, status)
                VALUES (?, ?, ?, ?, ?)
                """,
                (deviation_id, order, role, label, status)
            )

        write_audit(conn, deviation_id, "Deviation submitted — approval queue created", actor)
        conn.commit()

    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()

    return {"message": f"Deviation {deviation_id} submitted successfully.", "status": "in_review"}


# ── Internal helper ───────────────────────────────────────────────────────────

def _fetch_deviation(deviation_id: str) -> dict:
    """Fetches a single deviation row as a dict. Used internally."""
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM deviations WHERE id = ?", (deviation_id,)
    ).fetchone()
    conn.close()
    return dict(row) if row else None

# backend/routers/deviations.py  (add at the bottom)

# Add this import at the TOP of deviations.py with the other imports
# from agents.graph import run_analysis

@router.post("/{deviation_id}/analyse")
def analyse_deviation(deviation_id: str):
    """
    Triggers the LangGraph analysis pipeline for a deviation.
    Runs: Guardrail Agent → (if passed) Justification Agent

    On success: saves the AI justification and policy refs to the DB.
    On guardrail block: returns 422 with the blocking reason.

    Usage: POST /deviations/DEV-2410-A3F2/analyse
    """
    from agents.graph import run_analysis   # imported here to avoid circular import

    # Fetch the deviation
    deviation = _fetch_deviation(deviation_id)
    if not deviation:
        raise HTTPException(status_code=404, detail="Deviation not found")

    # Run the LangGraph pipeline
    result = run_analysis(deviation)

    # Guardrail blocked — return 422 with reason
    if not result["guardrail_passed"]:
        raise HTTPException(
            status_code=422,
            detail={
                "blocked_by": "guardrail",
                "reason":     result["guardrail_reason"],
                "risk_level": result["risk_level"]
            }
        )

    # Save AI outputs back to the deviation record
    conn = get_connection()
    try:
        conn.execute(
            """
            UPDATE deviations
            SET ai_justification = ?,
                policy_refs      = ?,
                updated_at       = datetime('now')
            WHERE id = ?
            """,
            (result["ai_justification"], result["policy_refs"], deviation_id)
        )
        write_audit(
            conn,
            deviation_id,
            f"AI analysis complete. Risk: {result['risk_level']}. "
            f"Justification generated.",
            "ai_system"
        )
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()

    return {
        "deviation_id":    deviation_id,
        "guardrail_passed": result["guardrail_passed"],
        "risk_level":       result["risk_level"],
        "ai_justification": result["ai_justification"],
        "policy_refs":      result["policy_refs"]
    }