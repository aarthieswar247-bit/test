# backend/routers/audit.py

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from fastapi import APIRouter, HTTPException, BackgroundTasks
from database import get_connection
from models import AuditEntry

router = APIRouter(prefix="/audit", tags=["Audit"])


# ── GET /audit/{deviation_id} — raw log ───────────────────────────────────────

@router.get("/{deviation_id}/log", response_model=list[AuditEntry])
def get_audit_log(deviation_id: str):
    """
    Returns the full raw audit trail for a deviation.
    Ordered newest first — matches the wireframe audit log display.
    """
    conn = get_connection()

    exists = conn.execute(
        "SELECT id FROM deviations WHERE id=?", (deviation_id,)
    ).fetchone()

    if not exists:
        conn.close()
        raise HTTPException(status_code=404, detail=f"Deviation {deviation_id} not found")

    rows = conn.execute(
        "SELECT * FROM audit_log WHERE deviation_id=? ORDER BY timestamp DESC",
        (deviation_id,)
    ).fetchall()
    conn.close()

    return [dict(r) for r in rows]


# ── POST /audit/{deviation_id}/summarise ─────────────────────────────────────

@router.post("/{deviation_id}/summarise")
def summarise_deviation(deviation_id: str):
    """
    Triggers the Audit Summariser Agent for a deviation.
    Generates an AI compliance summary and saves it to audit_summaries table.

    Best called after the workflow reaches approved or rejected status.
    Usage: POST /audit/DEV-2410-A3F2/summarise
    """
    from agents.auditor import generate_audit_summary

    conn = get_connection()
    dev = conn.execute(
        "SELECT status FROM deviations WHERE id=?", (deviation_id,)
    ).fetchone()
    conn.close()

    if not dev:
        raise HTTPException(status_code=404, detail="Deviation not found")

    if dev["status"] not in ("approved", "rejected"):
        raise HTTPException(
            status_code=409,
            detail=f"Deviation is '{dev['status']}'. "
                   f"Audit summary is generated after approved or rejected status only."
        )

    try:
        result = generate_audit_summary(deviation_id)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── GET /audit/{deviation_id}/summary ─────────────────────────────────────────

@router.get("/{deviation_id}/summary")
def get_audit_summary(deviation_id: str):
    """
    Returns the saved AI-generated audit summary for a deviation.
    Returns 404 if /summarise has not been called yet.
    """
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM audit_summaries WHERE deviation_id=?",
        (deviation_id,)
    ).fetchone()
    conn.close()

    if not row:
        raise HTTPException(
            status_code=404,
            detail="No audit summary found. Call POST /audit/{id}/summarise first."
        )

    return dict(row)


# ── GET /audit/{deviation_id}/export ─────────────────────────────────────────

@router.get("/{deviation_id}/export")
def export_deviation(deviation_id: str):
    """
    Returns the full regulatory export payload for a deviation.
    Includes: deviation record, approval chain, audit log,
    AI summary, compliance checklist, and integrity hash.

    This is the payload shown in the wireframe's
    'Reports & Export' panel.

    Usage: GET /audit/DEV-2410-A3F2/export
    """
    from agents.auditor import build_export_payload

    try:
        payload = build_export_payload(deviation_id)
        return payload
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── GET /audit/export/all ─────────────────────────────────────────────────────

@router.get("/export/all")
def export_all_summaries(limit: int = 50):
    """
    Returns all audit summaries across all deviations.
    Used by the Admin audit screen and bulk regulatory reporting.

    Usage: GET /audit/export/all?limit=100
    """
    conn = get_connection()

    rows = conn.execute(
        """SELECT
               s.deviation_id,
               s.outcome,
               s.risk_level,
               s.total_steps,
               s.duration_hours,
               s.generated_at,
               d.type,
               d.customer_name,
               d.requested_value,
               d.raised_by
           FROM audit_summaries s
           JOIN deviations d ON s.deviation_id = d.id
           ORDER BY s.generated_at DESC
           LIMIT ?""",
        (limit,)
    ).fetchall()
    conn.close()

    return {
        "total":   len(rows),
        "records": [dict(r) for r in rows]
    }


# ── GET /audit/ — all raw entries (admin) ────────────────────────────────────

@router.get("/")
def get_all_audit_entries(limit: int = 50):
    """
    Returns the most recent audit entries across all deviations.
    Used by the Admin audit screen.
    """
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT ?",
        (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]