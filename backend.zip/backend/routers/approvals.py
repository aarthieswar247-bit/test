# backend/routers/approvals.py

from fastapi import APIRouter, HTTPException
from database import get_connection, write_audit
from models import ApprovalAction, ApprovalStepResponse

router = APIRouter(prefix="/approvals", tags=["Approvals"])

# Which roles are allowed to act on each step role
# Senior approver can act on any step
ROLE_PERMISSIONS = {
    "ops":        ["ops", "senior"],
    "finance":    ["finance", "senior"],
    "network":    ["network", "senior"],
    "compliance": ["compliance", "senior"],
}


# ── GET /approvals/my-queue ───────────────────────────────────────────────────

@router.get("/my-queue", response_model=list[ApprovalStepResponse])
def get_my_queue(role: str):
    """
    Returns all approval steps currently pending for a given role.
    Usage: GET /approvals/my-queue?role=finance

    This is what populates the 'Pending My Approval' panel in the wireframe.
    """
    conn = get_connection()

    # Senior can see all pending steps across all roles
    if role == "senior":
        rows = conn.execute(
            "SELECT * FROM approval_steps WHERE status = 'pending' ORDER BY deviation_id"
        ).fetchall()
    else:
        rows = conn.execute(
            """
            SELECT * FROM approval_steps
            WHERE role_required = ? AND status = 'pending'
            ORDER BY deviation_id
            """,
            (role,)
        ).fetchall()

    conn.close()
    return [dict(r) for r in rows]


# ── POST /approvals/{step_id}/act ─────────────────────────────────────────────

@router.post("/{step_id}/act")
def act_on_step(step_id: int, payload: ApprovalAction):
    """
    Approve or reject a specific approval step.
    Enforces role-based access — only the correct role (or senior) can act.
    On approve: advances the queue to the next step.
    On reject:  marks the entire deviation as rejected.
    """

    # Validate action value
    if payload.action not in ("approve", "reject"):
        raise HTTPException(status_code=422, detail="action must be 'approve' or 'reject'")

    # Rejection requires a comment (compliance rule)
    if payload.action == "reject" and not payload.comment:
        raise HTTPException(
            status_code=422,
            detail="A comment is mandatory when rejecting a step."
        )

    conn = get_connection()

    # Fetch the step
    step = conn.execute(
        "SELECT * FROM approval_steps WHERE id = ?", (step_id,)
    ).fetchone()

    if not step:
        conn.close()
        raise HTTPException(status_code=404, detail="Approval step not found")

    if step["status"] != "pending":
        conn.close()
        raise HTTPException(
            status_code=409,
            detail=f"Step is '{step['status']}' — only 'pending' steps can be acted on."
        )

    # Role-based guardrail
    allowed_roles = ROLE_PERMISSIONS.get(step["role_required"], [])
    # Derive the acting user's role from the actor username convention
    # In Phase 7, this will come from a proper auth header
    actor_role = _infer_role(payload.actor)

    if actor_role not in allowed_roles:
        conn.close()
        raise HTTPException(
            status_code=403,
            detail=(
                f"Access denied. This step requires role '{step['role_required']}' "
                f"or 'senior'. Your role: '{actor_role}'."
            )
        )

    try:
        if payload.action == "approve":
            _handle_approve(conn, step, payload)
        else:
            _handle_reject(conn, step, payload)

        conn.commit()

    except HTTPException:
        conn.rollback()
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()

    return {"message": f"Step {step_id} {payload.action}d successfully."}


# ── Internal helpers ──────────────────────────────────────────────────────────

def _handle_approve(conn, step, payload: ApprovalAction):
    """Marks the step approved and activates the next waiting step."""

    # Mark current step as approved
    conn.execute(
        """
        UPDATE approval_steps
        SET status='approved', acted_by=?, comment=?, timestamp=datetime('now')
        WHERE id=?
        """,
        (payload.actor, payload.comment or "Approved", step["id"])
    )

    write_audit(
        conn,
        step["deviation_id"],
        f"{step['label']} approval granted. Comment: {payload.comment or 'None'}",
        payload.actor
    )

    # Find the next 'waiting' step in sequence
    next_step = conn.execute(
        """
        SELECT * FROM approval_steps
        WHERE deviation_id = ? AND step_order > ? AND status = 'waiting'
        ORDER BY step_order ASC
        LIMIT 1
        """,
        (step["deviation_id"], step["step_order"])
    ).fetchone()

    if next_step:
        # Activate the next step
        conn.execute(
            "UPDATE approval_steps SET status='pending' WHERE id=?",
            (next_step["id"],)
        )
        write_audit(
            conn,
            step["deviation_id"],
            f"{next_step['label']} step activated for review",
            "system"
        )
    else:
        # No more steps — deviation is fully approved
        conn.execute(
            "UPDATE deviations SET status='approved', updated_at=datetime('now') WHERE id=?",
            (step["deviation_id"],)
        )
        write_audit(
            conn,
            step["deviation_id"],
            "DEVIATION FULLY APPROVED — Ready for execution",
            "workflow"
        )


def _handle_reject(conn, step, payload: ApprovalAction):
    """Marks the step and the entire deviation as rejected."""

    conn.execute(
        """
        UPDATE approval_steps
        SET status='rejected', acted_by=?, comment=?, timestamp=datetime('now')
        WHERE id=?
        """,
        (payload.actor, payload.comment, step["id"])
    )

    conn.execute(
        "UPDATE deviations SET status='rejected', updated_at=datetime('now') WHERE id=?",
        (step["deviation_id"],)
    )

    write_audit(
        conn,
        step["deviation_id"],
        f"DEVIATION REJECTED by {step['label']}: {payload.comment}",
        payload.actor
    )


def _infer_role(actor: str) -> str:
    """
    Temporary helper: derives role from username convention.
    e.g. 'finance_user' → 'finance', 'senior_user' → 'senior'
    In Phase 7, this is replaced by a proper auth header.
    """
    for role in ("ops", "finance", "network", "compliance", "senior", "admin"):
        if role in actor.lower():
            return role
    return "unknown"

# backend/routers/approvals.py  (add at the bottom)

# Add these imports at the TOP of approvals.py
# import sys, os
# sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

@router.post("/workflow/start/{deviation_id}")
def start_workflow(deviation_id: str):
    """
    Starts the LangGraph approval workflow for a deviation.
    The deviation must already be in 'in_review' status with approval steps created.

    Usage: POST /approvals/workflow/start/DEV-2410-A3F2
    """
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    from agents.approval_graph import start_approval_workflow

    from database import get_connection
    conn = get_connection()
    dev = conn.execute(
        "SELECT * FROM deviations WHERE id=?", (deviation_id,)
    ).fetchone()
    conn.close()

    if not dev:
        raise HTTPException(status_code=404, detail="Deviation not found")
    if dev["status"] != "in_review":
        raise HTTPException(
            status_code=409,
            detail=f"Deviation status is '{dev['status']}'. "
                   f"Must be 'in_review' to start workflow. "
                   f"Run /analyse and /submit first."
        )

    result = start_approval_workflow(
        deviation_id=deviation_id,
        thread_id=deviation_id       # use deviation_id as thread_id
    )
    return result


@router.post("/workflow/resume/{deviation_id}")
def resume_workflow(deviation_id: str, payload: ApprovalAction):
    """
    Resumes a paused approval workflow after a human decision.
    Returns 403 if the actor does not have the required role for the current step.
    """
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    from agents.approval_graph import resume_approval_workflow

    if payload.action not in ("approve", "reject"):
        raise HTTPException(status_code=422, detail="action must be 'approve' or 'reject'")

    if payload.action == "reject" and not payload.comment:
        raise HTTPException(
            status_code=422,
            detail="A comment is mandatory when rejecting."
        )

    try:
        result = resume_approval_workflow(
            thread_id=deviation_id,
            action=payload.action,
            actor=payload.actor,
            comment=payload.comment or ""
        )
        return result

    except PermissionError as e:
        # Role enforcement — actor does not have permission for this step
        raise HTTPException(status_code=403, detail=str(e))

    except ValueError as e:
        # No workflow found for this thread_id
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/workflow/status/{deviation_id}")
def get_workflow_status(deviation_id: str):
    """
    Returns the current state of a running approval workflow.
    Usage: GET /approvals/workflow/status/DEV-2410-A3F2
    """
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    from agents.approval_graph import approval_graph

    config = {"configurable": {"thread_id": deviation_id}}
    state = approval_graph.get_state(config)

    if not state or not state.values:
        raise HTTPException(
            status_code=404,
            detail="No workflow found for this deviation. Start it first."
        )

    values = state.values
    return {
        "deviation_id":     deviation_id,
        "workflow_status":  values.get("workflow_status"),
        "current_role":     values.get("current_role"),
        "current_label":    values.get("current_label"),
        "ai_suggestion":    values.get("ai_suggestion"),
        "decisions_so_far": values.get("decisions", []),
    }