# backend/database.py

import sqlite3                      # Built-in Python module — no install needed
import os

# The database file will be created here when the app first runs
DB_PATH = os.path.join(os.path.dirname(__file__), "telcoflow.db")

def get_connection():
    """
    Returns a new SQLite connection.
    check_same_thread=False is needed for FastAPI which uses multiple threads.
    """
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row   # Makes rows behave like dicts (row["column_name"])
    return conn


def init_db():
    """
    Creates all tables if they don't already exist.
    Called once when the FastAPI app starts up.
    """
    conn = get_connection()
    cursor = conn.cursor()

    # --- Table 1: Users (simplified, no real auth yet) ---
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            username    TEXT NOT NULL UNIQUE,
            role        TEXT NOT NULL,   -- ops, finance, network, compliance, senior, admin
            created_at  TEXT DEFAULT (datetime('now'))
        )
    """)

    # --- Table 2: Deviations (the core request) ---
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS deviations (
            id              TEXT PRIMARY KEY,       -- e.g. DEV-2410-01
            type            TEXT NOT NULL,          -- billing credit, bandwidth, SLA waiver, etc.
            customer_name   TEXT NOT NULL,
            account_id      TEXT,
            scope           TEXT,                   -- description of the deviation
            requested_value REAL,
            standard_limit  REAL,
            urgency         TEXT DEFAULT 'Medium',  -- Low, Medium, High, Critical
            expiry_date     TEXT,
            status          TEXT DEFAULT 'draft',   -- draft, in_review, approved, rejected
            raised_by       TEXT,                   -- username of initiator
            ai_justification TEXT,                  -- AI-generated text (filled later)
            policy_refs     TEXT,                   -- comma-separated policy clause refs
            created_at      TEXT DEFAULT (datetime('now')),
            updated_at      TEXT DEFAULT (datetime('now'))
        )
    """)

    # --- Table 3: Approval Queue (one row per approver step) ---
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS approval_steps (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            deviation_id    TEXT NOT NULL,          -- FK → deviations.id
            step_order      INTEGER NOT NULL,       -- 1=Ops, 2=Finance, 3=Network, 4=Compliance
            role_required   TEXT NOT NULL,          -- ops, finance, network, compliance
            label           TEXT NOT NULL,          -- "Operations", "Finance", etc.
            status          TEXT DEFAULT 'waiting', -- waiting, pending, approved, rejected
            acted_by        TEXT,                   -- username who approved/rejected
            comment         TEXT,
            ai_suggestion   TEXT,                   -- per-step AI recommendation
            timestamp       TEXT,                   -- when the action was taken
            FOREIGN KEY (deviation_id) REFERENCES deviations(id)
        )
    """)

    # --- Table 4: Audit Log (immutable record of every action) ---
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS audit_log (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            deviation_id    TEXT,
            action          TEXT NOT NULL,          -- what happened
            actor           TEXT NOT NULL,          -- who/what triggered it
            timestamp       TEXT DEFAULT (datetime('now'))
        )
    """)

    # backend/database.py
# Add this block inside init_db(), after the audit_log CREATE TABLE

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS audit_summaries (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            deviation_id    TEXT NOT NULL UNIQUE,   -- one summary per deviation
            summary_text    TEXT NOT NULL,           -- AI-generated narrative
            risk_level      TEXT,
            outcome         TEXT,                    -- approved / rejected
            total_steps     INTEGER,
            duration_hours  REAL,                    -- time from creation to completion
            generated_by    TEXT DEFAULT 'ai_system',
            generated_at    TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (deviation_id) REFERENCES deviations(id)
        )
    """)

    conn.commit()
    conn.close()
    print("✅ Database initialised at:", DB_PATH)

def seed_users():
    """Insert default users for testing each role."""
    conn = get_connection()
    cursor = conn.cursor()
    users = [
        ("ops_user",        "ops"),
        ("finance_user",    "finance"),
        ("network_user",    "network"),
        ("compliance_user", "compliance"),
        ("senior_user",     "senior"),
        ("admin_user",      "admin"),
    ]
    # INSERT OR IGNORE skips the row if username already exists
    cursor.executemany(
        "INSERT OR IGNORE INTO users (username, role) VALUES (?, ?)",
        users
    )
    conn.commit()
    conn.close()
    print("✅ Seed users inserted.")



import uuid
from datetime import datetime

def generate_deviation_id() -> str:
    """
    Generates a unique ID like DEV-2410-A3F2.
    Uses the current year+month plus 4 random hex chars.
    """
    now = datetime.now()
    suffix = uuid.uuid4().hex[:4].upper()
    return f"DEV-{now.strftime('%y%m')}-{suffix}"


def write_audit(conn, deviation_id: str, action: str, actor: str):
    """
    Inserts one row into audit_log.
    Accepts an open connection so it can share a transaction with the caller.
    """
    conn.execute(
        """
        INSERT INTO audit_log (deviation_id, action, actor)
        VALUES (?, ?, ?)
        """,
        (deviation_id, action, actor)
    )
    # Note: caller is responsible for calling conn.commit()